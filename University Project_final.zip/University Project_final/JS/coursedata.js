var courseData = {
    courses:["Accounting and Financial Management", "Actuarial Science", "Anthropology", "Applied Mathematics","Engineering","Art","Science","Bio","Business","Mathmatics","Economics","Chemistry","Coop","Environment","French","Gender and Social Justice","Geography","History","Technology","Management","Kinesiology","Physics","Finance","Mathematical","Business Administration","Chartered Professional Accountancy","Music","Nursing","Philosophy","Sciences","Law","Spanish","Statistics","Teaching","Theatre","Tourism","Management","Biology","Psychology","Religious Studies","Religion","English","Health","Criminology","Fine Arts","Science","Dance","Design","Studies","Classical Studies","Classical","Pharmacology","Linguistics",]
}



